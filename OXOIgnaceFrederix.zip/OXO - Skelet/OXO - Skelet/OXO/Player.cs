﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace OXO
{
    public class Player
    {
        //Voorzie de properties hier
        public char CharToUse { get; set; }
        public Color ColorToUse { get; set; }




        public Player(char charToPlay, Color color)
        {
                             
            //Initialiseer de properties hier


        }
        
        public void ExecuteMove(Canvas tekenBlad, int XCoor, int YCoor)
        {
            Label l = new Label();
          
            l.Content = CharToUse;

            tekenBlad.Children.Add(l);


            //Voer zet uit en teken op canvas
        }

        
        private void DisplayOn(Canvas gameCanvas, int x, int y, string text, Color color)
        {
            Label l = new Label();
            l.Height = y;
            l.Width = x;
            l.Content = CharToUse;
            

                gameCanvas.Children.Add(l);


            
            
          
            //Toon de nieuwe zet op het canvas

            //Gebruik ActualWidth en ActualHeight om de dimensies van het canvas te kennen


        }
    }
}
