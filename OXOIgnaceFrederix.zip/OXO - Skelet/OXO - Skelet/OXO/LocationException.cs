﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OXO
{
    //Werk de exception uit
    public class LocationException
    {


        private void Plaats(int plaats1, int plaats2)
        {
            if (plaats1 == null && plaats2 ==null)
            {
                //er ziet niets op de plaats
            }
            else
            {
                throw new Exception( "De locatie is reeds in gebruik.");
            }

        }
    }
}
