﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows;
using System.IO;

namespace OXO
{
    public class Game
    {
        private Player[] player;
        private char[,] board;
        private int activePlayer;
        private Canvas tekenBlad;

        private DateTime startTime;

        public bool GameFinished { get; set; }
        public List<GameHistoryItem> GameHistory { get; set; }

        private DateTime[] begintijd = new DateTime[100];
        private DateTime[] eindtijd = new DateTime[100];
        private string[] score = new string[100];
        private int teller = 0;

        private string[] lijn = new string[100];


        public Game()
        {
            GameHistory = new List<GameHistoryItem>();
            player = new Player[2];

            player[0] = new Player('O', Colors.Aqua);
            player[1] = new Player('X', Colors.Brown);

            NewGame();

            startTime = DateTime.Now;
            activePlayer = 1;
            bool isPlaats = true;
            


        }
        public void DisplayOn(Canvas tekenBlad)
        {
            //Teken spel op canvas
            
            //Gebruik ActualWidth en ActualHeight om de dimensies van het canvas te kennen


        }

        public int HuidigePlayer
        {
            get
            {
                return activePlayer;
            }
        }

        public char KarPlayer1
        {
            get
            {
                return player[0].CharToUse;
            }
        }

        public char KarPlayer2
        {
            get
            {
                return player[1].CharToUse;
            }
        }

        public void ExecuteMove(int XPos, int YPos)
        {
            
           if(activePlayer == 1)
            {
                activePlayer = 2;
            }
            else
            {
                activePlayer = 1;
            }
            //Voer een zet uit in het spel
            
        }

        public bool won
        {
            get
            {
                return IsGameWon();
            }
        }


        private bool IsGameWon()
        {
            GameFinished = true;
            //Is er een winnaar
            return true;  //Dit statement moet worden gewijzigd
           
        }

        public void UpdateTime()
        {
            begintijd[teller] = startTime;
            if (IsGameWon = true)
            {
                eindtijd[teller] = DateTime.Now;
            }
            score[teller] = "xx-yy";
            teller++;
        }


        public string MaakLijn( int test)
        {
            return begintijd[test] + " \t" + eindtijd[test] + "\t" + score[test];
        }



        public override string ToString()
        {
            string test;
            if(activePlayer == 1)
            {
                test = "Speler " + activePlayer + " aan zet. plaats een " + player[0].CharToUse;
            }
            else
            {
                test = "Speler " + activePlayer + " aan zet. plaats een " + player[1].CharToUse;
            }
          
            return test;
        }

        public int Score( int playerNr)
        {
            //Haal de score van de speler op
            return 0; //Dit statement moet worden gewijzigd
        }

        public void NewGame()
        {
            //Start nieuw spel, bepaal random if je met Xof O speelt.
            Random rand = new Random();
            int randInt = rand.Next(0, 2);
            char player1Char = '\0', player2Char = '\0';

            if (randInt == 0)
            {
                player1Char = 'X';
                player2Char = 'O';
            }
            else
            {
                player1Char = 'O';
                player2Char = 'X';
            }

            player[0].CharToUse = player1Char;
            player[1].CharToUse = player2Char;

            board = new char[3, 3];
            activePlayer = 1;

            GameFinished = false;


        }

        public void IsPosValid(int x, int y)
        {

            try

            {
                if (activePlayer == 1)
                {
                    board[x, y] = KarPlayer1;
                }
                else
                {
                    board[x, y] = KarPlayer2;
                }



                LocationException.Plaats(x, y);
            }

            catch (LocationException ex)
            {
                string test;

                 test = (ex.Message);
            }

        }
        

        public void SaveGameHistory( string file )
        {
            //construeer een pad
            string destination = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            destination = System.IO.Path.Combine(destination, file);


            // maak connecite met een bestand
            StreamWriter outputStream = File.CreateText(destination);
            for (int i = 0; i < 100; i++)
            {
                outputStream.WriteLine(MaakLijn(i));
            }
            //sluit de connnectie
            outputStream.Close();
            

        }

        public string GetGameHistory( string file)
        {
            StringBuilder s1 = new StringBuilder();
            string destination = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            destination = System.IO.Path.Combine(destination, file);

          
            StreamReader inputStream = File.OpenText(destination);
            
            string line = inputStream.ReadLine();
            while (line != null)
            {
               
                s1.Append(line + "\n");
                line = inputStream.ReadLine();
            }
           
            inputStream.Close();
            return s1.ToString();
        }
    }
    
}
