﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OXO
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Game game;
        public MainWindow()
        {
            InitializeComponent();
            newGameButton.IsEnabled = false;
           
           
            

        }

        private void GenereerVierkand(int w, int h, int x, int y)
        {
            Rectangle rect = new Rectangle();
            rect.Width = w;
            rect.Height = h;
            rect.Margin = new Thickness(x, y, 10, 10);
            rect.Stroke = new SolidColorBrush(Colors.Black);
            gameCanvas.Children.Add(rect);
        }

        private void GenereerRaster()
        {
            //lijn 1
            GenereerVierkand(100, 100, 10, 10);
            GenereerVierkand(100, 100, 110, 10);
            GenereerVierkand(100, 100, 210, 10);
            //lijn2
            GenereerVierkand(100, 100, 10, 110);
            GenereerVierkand(100, 100, 110, 110);
            GenereerVierkand(100, 100, 210, 110);
            //lijn3
            GenereerVierkand(100, 100, 10, 210);
            GenereerVierkand(100, 100, 110, 210);
            GenereerVierkand(100, 100, 210, 210);
        }


        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            GenereerRaster();
          
          

            //Start nieuw spel
            //Toon spel op canvas en 
            //vul alle GUI elementen met de juiste waarde

        }

        private void playButton_Click(object sender, RoutedEventArgs e)
        {
            //Neem de nodige acties wanneer op de play button wordt gedrukt

            playButton.Content = game.ToString;
            playerTextBlock.Text = game.ToString;

            if (game.GameFinished == true)
            {
                newGameButton.IsEnabled = true;
                playButton.IsEnabled = false;
            }
            
          
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Acties wanneer de selectie van de combobox wordt gebruikt
            string x = XComboBox.Text;
            string y = YComboBox.Text;
            int xVal = Convert.ToInt32(x);
            int yVal = Convert.ToInt32(y);
            if(game.IsPosValid(xVal,yVal) = true)
            {
                ResetErrorField();
            }
        
        }

        private void newGameButton_Click(object sender, RoutedEventArgs e)
        {
            gameCanvas.Background = new SolidColorBrush(Colors.White);
            GenereerRaster();
            playButton.IsEnabled = true;
            newGameButton.IsEnabled = false;
           

        }

        private void ResetErrorField()
        {
            errorTextBox.Text = "";
        }

        
        private void MenuItem_WegSchrijven(object sender, RoutedEventArgs e)
        {




            game.SaveGameHistory("savefiletest");
           
        }


        private void MenuItem_LeesIn(object sender, RoutedEventArgs e)
        {

            string destination = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            OpenFileDialog filedialog = new OpenFileDialog();
            filedialog.InitialDirectory = destination;
            filedialog.Filter = "Text files|*.txt|All files|*.*";
            if (filedialog.ShowDialog() == true)
            {
              
                StreamReader inputStream = File.OpenText(filedialog.FileName);

               
                inputStream.Close();

            }
        }

        private void MenuItem_Exit(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
            
        }

        private void MenuItem_ShowHistory(object sender, RoutedEventArgs e)
        {
             ShowHistory hist =  new ShowHistory();
            hist.Show();
            hist.listBox.Content = game.GetGameHistory("savefiletest");
        }
    }
}
